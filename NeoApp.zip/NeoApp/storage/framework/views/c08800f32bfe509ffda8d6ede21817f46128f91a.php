

<?php $__env->startSection('content'); ?>
 
<form method="post" action="<?php echo e(route('/')); ?>">
	<div class="row pt-3">
		<div class="col-sm-5">
			<label>Choose Date</label>
			<input type="text" name="date" class="form-control" required="">
		</div>
		<div class="col-sm-5 pt-4">
			<button class="btn btn-sm btn-success">Submit</button>
		</div>
	</div>
	<?php echo csrf_field(); ?>
</form>


<?php if(isset($velocity)): ?>
<div class="row">
	<div class="col-sm-12"><h4>Results</h4></div>
	<div class="col-sm-6">

         <?php $__currentLoopData = $velocity; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <h6><?php echo e($item['date']); ?></h6>
           <p>Fastest speed: <?php echo e($item['velocity']); ?></p>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		
	</div>
	<div class="col-sm-6">
		<canvas id="myChart"></canvas>
	</div>
</div>
<?php endif; ?>

<?php $__env->startPush('chart'); ?>
<script>
	var ctx = document.getElementById('myChart');
	var myChart = new Chart(ctx, {
	    type: 'bar',
	    data: {
	        labels: [<?php if(isset($label)): ?>
                       <?php $__currentLoopData = $label; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        '<?php echo e($item); ?>',
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	                  <?php endif; ?>],
	        datasets: [{
	            label: '# ',
	            data: [<?php if(isset($data)): ?>
                       <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($item); ?>,
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	                  <?php endif; ?>],
	            backgroundColor: [
	                'rgba(255, 99, 132, 0.2)',
	                'rgba(54, 162, 235, 0.2)',
	                'rgba(255, 206, 86, 0.2)',
	                'rgba(75, 192, 192, 0.2)',
	                'rgba(153, 102, 255, 0.2)',
	                'rgba(255, 159, 64, 0.2)'
	            ],
	            borderColor: [
	                'rgba(255, 99, 132, 1)',
	                'rgba(54, 162, 235, 1)',
	                'rgba(255, 206, 86, 1)',
	                'rgba(75, 192, 192, 1)',
	                'rgba(153, 102, 255, 1)',
	                'rgba(255, 159, 64, 1)'
	            ],
	            borderWidth: 1
	        }]
	    },
	    options: {
	        scales: {
	            y: {
	                beginAtZero: true
	            }
	        }
	    }
	});
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppp\htdocs\NeoApp\resources\views/neo/index.blade.php ENDPATH**/ ?>